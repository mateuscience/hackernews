#!/usr/bin/env node

// Take the number of top stories requested by the user
how_many = process.argv[2];
if ((how_many) > 100) {
    how_many = 100;
};
if ((how_many) < 1) {
    how_many = 0;
};
if (isNaN(how_many) == true){
    how_many = 0;
};

// Introduction
if (how_many > 0) {
    console.log( "Hackernews is running!");
};

// Set the global variable hn
var hn = require('hackernews-api');

// Get the top stories limited to 500
stories_all = hn.getTopStories('hackernews-api');

// Pick the top stories chosen by the user
top_stories = stories_all.slice(0, how_many);

// Initialize the story ranking
rank = 1;

// Loop through the stories
top_stories.forEach(readStories);

    // Output to STDOUT
    function readStories(value, index, array) {

        story = hn.getItem(value);

        // Remove unecessary properties
        delete story.kids;
        delete story.type; 
        delete story.time;
        delete story.id;

        // Title and author are non empty strings <= 256 characters
        var title = story.title;
        var author = story.by;
        if (title) {
            title = title.substring(0,256);
        } else {
            title = 'Title unknown';
        };
        if (author) {
            author = author.substring(0,256);
        } else {
            author = 'Author unknown';
        };

        // Points, comments and rank are integers >= 0
        var points   = story.score;
        var comments = story.descendants;
        points   = parseInt(points);
        comments = parseInt(comments);
        if (points <= 0) {
            points = 1;
        };
        if (comments <= 0) {
            comments = 1;
        };
       
        // URL validation:
        if (is_url(story.url) == true) {
            uri = story.url;
        } else {
            uri = 'URI unknown';
        };

        function is_url(str) {
          regexp =  /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
            if (regexp.test(str)) { return true; }
            else { return false; }
        };

        // Format the data object
        var new_story = {
            'title': title,
            'uri': uri,
            'author': author,
            'points': points,
            'comments': comments,
            'rank': rank
        };
       
        // Convert the data object into JSON format
        myJSON = JSON.stringify(new_story,null,'\t');

        // Print the data
        console.log(myJSON);

        rank++;
    };